import type { BrandHero, GalleryItem, Service, Stat, TickerItem } from './types';

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`${path} failed (${res.status})`);
  return res.json();
}

export const fetchBrand = () => get<BrandHero>('/api/brand');
export const fetchStats = () => get<Stat[]>('/api/stats');
export const fetchServices = () => get<Service[]>('/api/services');
export const fetchTicker = () => get<TickerItem[]>('/api/ticker');
export const fetchGallery = () => get<GalleryItem[]>('/api/gallery');
